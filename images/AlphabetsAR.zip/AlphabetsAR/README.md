# Alphabets Learning App for Kids using Augmented Reality (WebAR)

Use https://vaibogam.github.io/AlphabetsBook/ for scanning markers